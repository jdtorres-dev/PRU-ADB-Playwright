import { test, expect } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import { HrMasterConsole } from '../src/console-page';
import {
  extractArtifacts,
  parseLnaReport,
  parseControlReport,
  refusalAtRecord,
  LnaRefusal,
} from '../src/artifact-validator';

/* ------------------------------------------------------------------ config */

const CREDENTIALS = { username: 'admin', password: 'admin' };

const DATA_ROOT = 'C:\\Users\\RSERRANO\\PRU ADB\\Test Data Scenarios for Demo';
const TEST_DATA_FILE = path.join(DATA_ROOT, '006_Merged File',
  'ALLSTATE.LNA.DEMO-MERGED-BR031-035.D20260908.txt');
const FEED_DATE = '20260908';                       // from the file's submitting header
const OUT_ROOT = path.join(__dirname, '..', 'artifacts');

/**
 * The five test cases, taken from Test Scenarios for Demo.xlsx.
 * `producerRecord` is the record position within the merged feed file, which is
 * how a refusal in the LNA report is tied back to its test case.
 */
interface TestCase {
  id: string;
  rule: string;
  expectedCode: string;
  fieldUnderTest: string;
  producerRecord: number;
  expectedFirm: string;
}

const TEST_CASES: TestCase[] = [
  { id: 'DEMO-01', rule: 'BR-031', expectedCode: 'D0101', fieldUnderTest: 'WS-SOC-SEC-NUM', producerRecord: 4,  expectedFirm: 'SAMPLE BROKERAGE G05 F001 LLC' },
  { id: 'DEMO-02', rule: 'BR-033', expectedCode: 'D0104', fieldUnderTest: 'WS-DOB',         producerRecord: 9,  expectedFirm: 'SAMPLE BROKERAGE G05 F002 LLC' },
  { id: 'DEMO-03', rule: 'BR-034', expectedCode: 'D0105', fieldUnderTest: 'WS-SEX-CD',      producerRecord: 14, expectedFirm: 'SAMPLE BROKERAGE G05 F003 LLC' },
  { id: 'DEMO-04', rule: 'BR-035', expectedCode: 'D0106', fieldUnderTest: 'WS-HOME-ST-CD',  producerRecord: 19, expectedFirm: 'SAMPLE BROKERAGE G05 F004 LLC' },
  { id: 'DEMO-05', rule: 'BR-035', expectedCode: 'D0106', fieldUnderTest: 'WS-HOME-ZIP-CD', producerRecord: 24, expectedFirm: 'SAMPLE BROKERAGE G05 F005 LLC' },
];

interface Verdict {
  testCaseId: string;
  rule: string;
  testDataFile: string;
  feedDate: string;
  runId: string;
  artifactZip: string;
  expectedCode: string;
  actualCode: string;
  actualDescription: string;
  verdict: 'PASS' | 'FAIL' | 'BLOCKED';
  notes: string;
}

const results: Verdict[] = [];

/* ------------------------------------------------------------------- suite */

test.describe.serial('PRU ADB — producer validation (BR-031 to BR-035)', () => {
  let runId = '';
  let zipPath = '';
  let refusals: LnaRefusal[] = [];
  let controlReportPath: string | undefined;
  let blockedReason = '';

  test('upload the feed file through the HR Master Console and download its artifacts', async ({ page }) => {
    const console_ = new HrMasterConsole(page);

    await test.step('log in', async () => {
      await console_.login(CREDENTIALS.username, CREDENTIALS.password);
    });

    await test.step('open the upload tab', async () => {
      await console_.openUploadTab();
    });

    await test.step(`set the feed date to ${FEED_DATE}`, async () => {
      await console_.setFeedDate(FEED_DATE);
    });

    await test.step('select the test data file', async () => {
      expect(fs.existsSync(TEST_DATA_FILE), `test data missing: ${TEST_DATA_FILE}`).toBeTruthy();
      await console_.chooseFile(TEST_DATA_FILE);
    });

    await test.step('submit the upload', async () => {
      runId = await console_.submitAndGetRunId();
      expect(runId).toBeTruthy();
      test.info().annotations.push({ type: 'runId', description: runId });
    });

    await test.step('wait for processing to finish', async () => {
      const run = await console_.waitForRunToSettle(runId);
      test.info().annotations.push({ type: 'runStatus', description: String(run?.status) });
    });

    await test.step('download the General Artifacts ALL (.zip)', async () => {
      await console_.openRun(runId);
      zipPath = path.join(OUT_ROOT, `run-${runId}`, `ingestion-artifacts-${runId}.zip`);
      await console_.downloadAllArtifacts(zipPath);
      expect(fs.existsSync(zipPath)).toBeTruthy();
      expect(fs.statSync(zipPath).size).toBeGreaterThan(0);
    });

    await test.step('extract the artifacts and record the run manifest', async () => {
      const extractedDir = path.join(OUT_ROOT, `run-${runId}`, 'extracted');
      const extracted = extractArtifacts(zipPath, extractedDir);
      test.info().annotations.push({ type: 'artifactFiles', description: extracted.files.length.toString() });

      // The manifest is what ties every downstream verdict back to this exact run.
      fs.writeFileSync(path.join(OUT_ROOT, 'run-manifest.json'), JSON.stringify({
        runId, feedDate: FEED_DATE, testDataFile: path.basename(TEST_DATA_FILE),
        zipPath, extractedDir,
        lnaReportPath: extracted.lnaReportPath ?? null,
        controlReportPath: extracted.cntlrptPath ?? null,
        executedAt: new Date().toISOString(),
      }, null, 2));

      expect(extracted.lnaReportPath, 'artifacts ZIP must contain an LNA report').toBeTruthy();
    });
  });

});
