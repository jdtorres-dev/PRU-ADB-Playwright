import { test, expect } from '@playwright/test';
import * as fs from 'fs';
import * as path from 'path';
import {
  parseLnaReport,
  parseControlReport,
  refusalAtRecord,
  LnaRefusal,
} from '../src/artifact-validator';

/**
 * Validation phase.
 *
 * Reads the artifacts downloaded by 01-execute-upload.spec.ts and judges every
 * test case on what the application actually produced. Deliberately separate
 * from the execution phase: the environment has no data reset, so re-running an
 * upload consumes identifiers, while validation can be re-run freely.
 *
 * No test here touches the application. The verdict comes from the LNA report
 * and, where no error code is expected, the control report.
 */

const OUT_ROOT = path.join(__dirname, '..', 'artifacts');
const MANIFEST = path.join(OUT_ROOT, 'run-manifest.json');
const IDENTITY = path.join(
  'C:/Users/RSERRANO/PRU ADB/Test Data Scenarios for Demo', '_MERGED-IDENTITY.json');

/**
 * The bundle identities change every time the file is reissued (the environment
 * has no data reset). Read them from the identity file the reissue writes, rather
 * than hard-coding a generation that goes stale on the next run.
 */
function firmFor(producerRecord: number): string {
  const id = JSON.parse(fs.readFileSync(IDENTITY, 'utf8'));
  const b = id.bundles.find((x: any) => x.producer_rec === producerRecord);
  if (!b) throw new Error(`No bundle in _MERGED-IDENTITY.json at producer record ${producerRecord}`);
  return b.firm as string;
}

interface TestCase {
  id: string;
  rule: string;
  expectedCode: string;
  expectedDescription: string;
  fieldUnderTest: string;
  producerRecord: number;
}

const TEST_CASES: TestCase[] = [
  { id: 'DEMO-01', rule: 'BR-031', expectedCode: 'D0101', expectedDescription: 'SSN INVALID IN THE "PRODUCER ENTITY" RECORD - RECORD REJECTED',            fieldUnderTest: 'WS-SOC-SEC-NUM', producerRecord: 4 },
  { id: 'DEMO-02', rule: 'BR-033', expectedCode: 'D0104', expectedDescription: 'DATE OF BIRTH INVALID IN THE "PRODUCER ENTITY" RECORD - RECORD REJECTED',  fieldUnderTest: 'WS-DOB',         producerRecord: 9 },
  { id: 'DEMO-03', rule: 'BR-034', expectedCode: 'D0105', expectedDescription: 'SEX CODE INVALID IN THE "PRODUCER ENTITY" RECORD - RECORD REJECTED',       fieldUnderTest: 'WS-SEX-CD',      producerRecord: 14 },
  { id: 'DEMO-04', rule: 'BR-035', expectedCode: 'D0106', expectedDescription: 'HOME ADDRESS INVALID IN THE "PRODUCER ENTITY" RECORD - RECORD REJECTED',   fieldUnderTest: 'WS-HOME-ST-CD',  producerRecord: 19 },
  { id: 'DEMO-05', rule: 'BR-035', expectedCode: 'D0106', expectedDescription: 'HOME ADDRESS INVALID IN THE "PRODUCER ENTITY" RECORD - RECORD REJECTED',   fieldUnderTest: 'WS-HOME-ZIP-CD', producerRecord: 24 },
];

interface Verdict {
  testCaseId: string;
  rule: string;
  fieldUnderTest: string;
  producerRecord: number;
  testDataFile: string;
  feedDate: string;
  runId: string;
  artifactZip: string;
  expectedCode: string;
  expectedDescription: string;
  actualCode: string;
  actualDescription: string;
  verdict: 'PASS' | 'FAIL' | 'BLOCKED';
  notes: string;
}

const VERDICT_DIR = path.join(OUT_ROOT, 'verdicts');

/**
 * Each verdict is written to its own file the moment it is decided.
 * Playwright restarts the worker after a failing test, which would discard an
 * in-memory accumulator and silently lose the verdicts recorded before it.
 */
function recordVerdict(v: Verdict): void {
  fs.mkdirSync(VERDICT_DIR, { recursive: true });
  fs.writeFileSync(path.join(VERDICT_DIR, `${v.testCaseId}.json`), JSON.stringify(v, null, 2));
}

let manifest: any = null;
let refusals: LnaRefusal[] = [];

test.beforeAll(() => {
  expect(fs.existsSync(MANIFEST), `run manifest missing — run 01-execute-upload first`).toBeTruthy();
  manifest = JSON.parse(fs.readFileSync(MANIFEST, 'utf8'));

  const lna = manifest.lnaReportPath && fs.existsSync(manifest.lnaReportPath)
    ? manifest.lnaReportPath
    : findFile(manifest.extractedDir, /lnaerror/i);
  expect(lna, 'LNA report not found in the extracted artifacts').toBeTruthy();
  refusals = parseLnaReport(lna!);
});

function findFile(root: string, re: RegExp): string | undefined {
  const stack = [root];
  while (stack.length) {
    const d = stack.pop()!;
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) stack.push(p);
      else if (re.test(e.name)) return p;
    }
  }
  return undefined;
}

for (const tc of TEST_CASES) {
  test(`${tc.id} ${tc.rule} — ${tc.fieldUnderTest} at record ${tc.producerRecord} expects ${tc.expectedCode}`, async () => {
    const refusal = refusalAtRecord(refusals, tc.producerRecord);
    const actualCode = refusal?.errorCode ?? '';
    const actualDescription = refusal?.errorDescription ?? '';

    let verdict: Verdict['verdict'] = 'FAIL';
    let notes: string;

    if (!refusal) {
      notes = `No refusal reported at record ${tc.producerRecord}. The producer was ACCEPTED by the application `
            + `when the business rule requires it to be refused under ${tc.expectedCode}.`;
    } else if (refusal.firmName !== firmFor(tc.producerRecord)) {
      notes = `Refusal at record ${tc.producerRecord} names firm "${refusal.firmName}" but this test case's bundle `
            + `is "${firmFor(tc.producerRecord)}" - the result cannot be attributed to this test case.`;
    } else if (actualCode !== tc.expectedCode) {
      notes = `Refused under ${actualCode} rather than the expected ${tc.expectedCode}.`;
    } else {
      verdict = 'PASS';
      notes = `Matched on record position, firm name and error code.`;
    }

    recordVerdict({
      testCaseId: tc.id, rule: tc.rule, fieldUnderTest: tc.fieldUnderTest,
      producerRecord: tc.producerRecord,
      testDataFile: manifest.testDataFile, feedDate: manifest.feedDate,
      runId: manifest.runId, artifactZip: manifest.zipPath,
      expectedCode: tc.expectedCode, expectedDescription: tc.expectedDescription,
      actualCode, actualDescription, verdict, notes,
    });

    expect(actualCode, notes).toBe(tc.expectedCode);
  });
}

test('control report — bundle and contract counts must agree with the refusals', async () => {
  const cntl = manifest.controlReportPath && fs.existsSync(manifest.controlReportPath)
    ? manifest.controlReportPath
    : findFile(manifest.extractedDir, /cntlrpt/i);
  expect(cntl, 'control report not found').toBeTruthy();

  const report = parseControlReport(cntl!);
  fs.writeFileSync(path.join(OUT_ROOT, 'control-report-parsed.json'), JSON.stringify(report, null, 2));

  // The three interface controls must all have passed, or no producer rule was ever reached.
  for (const [k, v] of Object.entries(report.checks)) {
    if (/COMPANY NAME|TRANSMISSION DATE|RECORD COUNT/i.test(k)) {
      expect(v, `interface control "${k}"`).toBe('YES');
    }
  }

  // Five bundles in, five bundles processed.
  const bundles = report.counters['NUMBER OF BD FIRM BUNDLES PRESENT IN THE LNA FILE'];
  expect(bundles, 'bundles present').toBe(5);

  // Every producer that was refused must NOT have produced an IP contract.
  const ipCreated = report.counters['NUMBER OF INVESTMENT PROFESSIONALS CONTRACTS CREATED IN ADB'] ?? 0;
  const expectedRefusals = TEST_CASES.length;
  const actualRefusals = refusals.filter((r) => r.recordType.startsWith('D01')).length;
  const accepted = expectedRefusals - actualRefusals;

  expect(ipCreated,
    `${ipCreated} investment-professional contract(s) were created. Every one of the ${expectedRefusals} `
    + `producers in this file carries a deliberate fault, so none should have been accepted. `
    + `${accepted} producer(s) were accepted without a refusal.`).toBe(0);
});

test.afterAll(() => {
  if (!fs.existsSync(VERDICT_DIR)) return;
  const all: Verdict[] = fs.readdirSync(VERDICT_DIR)
    .filter((f) => f.endsWith('.json'))
    .map((f) => JSON.parse(fs.readFileSync(path.join(VERDICT_DIR, f), 'utf8')))
    .sort((a, b) => a.testCaseId.localeCompare(b.testCaseId));
  fs.writeFileSync(path.join(OUT_ROOT, 'verdicts.json'), JSON.stringify(all, null, 2));
  console.log('');
  console.log('  TEST CASE   EXPECTED  ACTUAL    VERDICT');
  for (const v of all) {
    console.log('  ' + v.testCaseId.padEnd(11) + ' ' + v.expectedCode.padEnd(9) + ' '
      + (v.actualCode || '-').padEnd(9) + ' ' + v.verdict);
  }
});
