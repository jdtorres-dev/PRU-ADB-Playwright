# PRU ADB — E2E automation (BRD v4)

Runs the whole BRD v4 test suite through the HR Master Console the same way the
five-case demo ran: log in, set the feed date, upload, wait for the run, download
the General Artifacts ZIP, read the artifacts, record a verdict.

**Nothing here has been executed yet.**

---

## What it covers

| | |
|---|---:|
| Test cases in the workbook | 284 |
| Feed files uploaded | 68 |
| Cases whose condition the feed actually forces | 88 |
| Cases blocked — condition not drivable from the feed | 196 |

The 88 are the only cases that can return Pass or Fail. The rest are recorded
`BLOCKED` with the reason, because their outcome is not something the file can
cause. See *Why so many are blocked* below.

## Before the first run

```bash
npm install
npx playwright install chromium
```

## Running it

```bash
# 1. Issue a fresh generation. Mandatory — see "No data reset".
python scripts/reissue_e2e.py 7

# 2. Upload all 68 feed files and download their artifacts.
npm run e2e:execute

# 3. Judge every test case against what came back. Touches nothing; re-runnable.
npm run e2e:validate

# 4. Write the verdicts into the workbook.
npm run e2e:excel
```

`npm run e2e:plan` lists what step 2 would upload, without uploading anything.

To run one feed file only:

```bash
npx playwright test --project=e2e-execute --grep "B0607"
```

## No data reset

The environment never resets. A bundle whose firm record passes validation
commits its organisation, and presenting the same identifiers again raises
**B0700** instead of the condition under test.

`scripts/reissue_e2e.py <n>` rebuilds all 68 feed files with generation-`n`
identifiers — every bundle in the whole set gets an identifier no other bundle
has, in this run or any previous one — then refreshes the record indexes and the
test-case registry.

Run it immediately before an execution. Never during one. `data/generation.json`
records which generation the feeds currently carry, and the execution phase
refuses to start without it.

## How a verdict is decided

Three rules, applied in this order:

1. **A Confidence C rule is `OBSERVED`.** BRD v4 says the source contradicts
   itself, so no expected result can be stated. Behaviour is recorded, never
   passed or failed. QA Test Plan v1.00 §6.3.
2. **A case whose condition the file does not force is `BLOCKED`.** Not `FAIL`.
3. **An automation or environment failure is `BLOCKED`.** Not `FAIL`. If the
   upload throws, the run record carries the error and every case on that feed is
   blocked with it quoted.

Otherwise:

- **Negative case** — the expected code must appear in the LNA report against
  one of that bundle's record positions. A different code firing first is `FAIL`
  with a note that it may be masking the rule under test.
- **Positive case** — no refusal against the bundle, *and* its broker dealer
  identifier present in the LOADFILE. Absence of a refusal alone is not enough:
  a bundle can be neither refused nor applied, and that is a finding.

An automation problem is never written up as an application defect, and a `FAIL`
is never promoted.

## Why so many are blocked

Of the 284 cases, 196 cannot return a verdict:

| Reason | Cases |
|---|---:|
| Rule's fields are internal working storage with no position in the feed layout | 146 |
| Destination produces no downloadable artifact (Java exception, log only) | 31 |
| Condition depends on state already committed in ADB, not on file content | 16 |
| Condition sits on the submitting header, needs a single-rule file | 3 |

These are recorded honestly rather than hidden: each verdict file states why, and
the workbook's Notes column carries the same text. The 16 precondition cases
become executable once the prior state is set up; the 3 header-level ones need
three more feed files.

## Layout

```
scripts/
  reissue_e2e.py        rebuild all feeds under a fresh generation
  build_registry.py     workbook + feed indexes -> data/*.json
  make_feeds.py         58 error-code feeds
  make_feeds_dest.py    9 destination feeds + the positive baseline
  update_excel_e2e.py   verdicts -> workbook
data/
  test-cases.json       284 cases, each with its feed file and record positions
  feeds.json            68 feed files in upload order
  generation.json       which generation the feeds carry
src/
  console-page.ts       HR Master Console page object (shared with the demo)
  artifact-validator.ts ZIP extraction, LNA/CNTLRPT parsing, artifact location
  registry.ts           typed loaders for data/*.json
  verdict-store.ts      per-case verdict and per-feed run records
tests/
  01-execute-upload.spec.ts    demo (BR-031 to BR-035, v3 ids)
  02-validate-artifacts.spec.ts
  e2e-01-execute.spec.ts       upload 68 feeds
  e2e-02-validate.spec.ts      judge 284 cases
artifacts/e2e/
  runs/<feed>.json             one record per feed uploaded
  runs/run-<id>/               the ZIP and its extracted contents
  verdicts/<case>.json         one file per verdict, written as it is decided
```

Verdicts are written to disk the moment they are decided. Playwright restarts the
worker after a failing test, which would discard an in-memory accumulator and
silently lose everything recorded before it — that happened during the demo.

## Expected duration

68 uploads, each with its own run to settle, at roughly 45–90 seconds. Budget
**1.5 to 2 hours** for the execution phase, running serially with one worker.
Serial is deliberate: concurrent runs would interleave in an environment that
has no data reset. Validation takes under a minute.
