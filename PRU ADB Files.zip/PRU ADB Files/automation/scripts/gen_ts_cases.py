# -*- coding: utf-8 -*-
"""Emit all 284 test cases as a typed TypeScript module.

The suite runs data-driven: e2e-02-validate.spec.ts reads data/test-cases.json and
generates one Playwright test per case. That keeps the workbook as the single
definition of record, but it means the 284 cases are not visible as TypeScript.

This writes them out as typed constants so they can be read, reviewed and
searched in an editor. Generated - do not hand-edit; rebuild with
    python scripts/gen_ts_cases.py
"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "..", "data", "test-cases.json")
OUT = os.path.join(HERE, "..", "tests", "test-cases.generated.ts")


def ts(v):
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, (int, float)):
        return str(v)
    if v is None:
        return "''"
    s = str(v).replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ").replace("\r", " ")
    return "'" + s + "'"


def main():
    cases = json.load(open(SRC, encoding="utf-8"))
    lines = [
        "/**",
        " * All %d E2E test cases, as typed constants." % len(cases),
        " *",
        " * GENERATED FILE - do not hand-edit. Rebuild with:",
        " *     python scripts/gen_ts_cases.py",
        " *",
        " * The suite itself runs from data/test-cases.json, which this mirrors. The",
        " * workbook PRU_ADB_E2E_Test_Scenarios_v4.xlsx remains the definition of record;",
        " * both this file and the JSON are built from it by scripts/build_registry.py.",
        " *",
        " * Verdicts are decided on DESTINATION, not on an error code matching:",
        " *   conditionForced true  - the feed forces the rule's condition, so the output",
        " *                           must reach destinationArtifact.",
        " *   conditionForced false - the record is valid, so it must be applied to the",
        " *                           load output and appear on no error report.",
        " */",
        "",
        "export interface FeedTarget {",
        "  /** Feed file this rule's records live in. */",
        "  feed: string;",
        "  /** 1-based bundle number within the file. */",
        "  bundleIndex: number;",
        "  /** Record positions, counting the submitting header as record 1. */",
        "  recordStart: number;",
        "  recordEnd: number;",
        "  recordCount: number;",
        "  /** How the record is driven: fault injected, structural, positive, carrier, ... */",
        "  cls: string;",
        "  note: string;",
        "  /** Broker dealer identifier, used to trace the record into the load output. */",
        "  bd: string;",
        "}",
        "",
        "export interface E2ETestCase {",
        "  id: string;",
        "  rule: string;",
        "  topic: string;",
        "  type: string;",
        "  priority: string;",
        "  route: string;",
        "  /** Confidence C in BRD v4 - observe and record, never Pass or Fail. */",
        "  bcr: boolean;",
        "  expectedCode: string;",
        "  expectedDescription: string;",
        "  expectedDestination: string;",
        "  /** LNAERROR | ADBSKIP | CNTLRPT | LOADFILE | ERRFILE | '' */",
        "  destinationArtifact: string;",
        "  /** True when the feed file actually forces this rule's condition. */",
        "  conditionForced: boolean;",
        "  validationSource: string;",
        "  program: string;",
        "  feeds: FeedTarget[];",
        "  executable: boolean;",
        "  blockedReason: string;",
        "}",
        "",
        "export const E2E_TEST_CASES: readonly E2ETestCase[] = [",
    ]

    order = ["id", "rule", "topic", "type", "priority", "route", "bcr", "expectedCode",
             "expectedDescription", "expectedDestination", "destinationArtifact",
             "conditionForced", "validationSource", "program"]
    for c in cases:
        lines.append("  {")
        for k in order:
            lines.append("    %s: %s," % (k, ts(c.get(k, ""))))
        if c["feeds"]:
            lines.append("    feeds: [")
            for f in c["feeds"]:
                lines.append("      { feed: %s, bundleIndex: %d, recordStart: %d, recordEnd: %d,"
                             % (ts(f["feed"]), f["bundleIndex"], f["recordStart"], f["recordEnd"]))
                lines.append("        recordCount: %d, cls: %s, bd: %s,"
                             % (f["recordCount"], ts(f["cls"]), ts(f.get("bd", ""))))
                lines.append("        note: %s }," % ts(f["note"]))
            lines.append("    ],")
        else:
            lines.append("    feeds: [],")
        lines.append("    executable: %s," % ts(c["executable"]))
        lines.append("    blockedReason: %s," % ts(c["blockedReason"]))
        lines.append("  },")
    lines.append("];")
    lines += [
        "",
        "/** Cases the run can return PASS or FAIL for. */",
        "export const EXECUTABLE = E2E_TEST_CASES.filter((c) => c.executable);",
        "",
        "/** Cases with no readable destination, so no verdict is possible. */",
        "export const BLOCKED = E2E_TEST_CASES.filter((c) => !c.executable);",
        "",
        "/** Cases whose own condition the feed file forces - a pass here proves the rule. */",
        "export const RULE_PROVING = EXECUTABLE.filter((c) => c.conditionForced);",
        "",
        "/** Valid records - a pass here proves routing, not the rule. */",
        "export const ROUTING_ONLY = EXECUTABLE.filter((c) => !c.conditionForced);",
        "",
    ]
    open(OUT, "w", encoding="utf-8").write("\n".join(lines))

    ex = sum(1 for c in cases if c["executable"])
    print("wrote", os.path.normpath(OUT))
    print("  %d test cases | %d executable | %d blocked" % (len(cases), ex, len(cases) - ex))


if __name__ == "__main__":
    main()
