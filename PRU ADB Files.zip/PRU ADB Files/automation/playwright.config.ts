import { defineConfig } from '@playwright/test';

/**
 * PRU ADB HR Master Console — Playwright configuration.
 *
 * ignoreHTTPSErrors is required: the Elastic Beanstalk dev host serves a
 * certificate that does not chain to a trusted authority. Without it the
 * browser refuses to navigate at all (ERR_CERT_AUTHORITY_INVALID).
 */
export default defineConfig({
  testDir: './tests',
  timeout: 10 * 60 * 1000,         // 68 uploads, each with its own run to settle
  expect: { timeout: 30 * 1000 },
  fullyParallel: false,             // the environment has no data reset; runs must not overlap
  workers: 1,
  retries: 0,                       // a retry would re-present committed identifiers and hit B0700
  reporter: [
    ['list'],
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    ['json', { outputFile: 'artifacts/results.json' }],
  ],
  use: {
    baseURL: 'https://pru-adb-dev.ap-southeast-1.elasticbeanstalk.com',
    ignoreHTTPSErrors: true,
    actionTimeout: 30 * 1000,
    navigationTimeout: 60 * 1000,
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
    video: 'off',
  },
  projects: [
    // The original five-case demo (BR-031 to BR-035, v3 catalogue ids).
    {
      name: 'demo',
      testMatch: ['01-execute-upload.spec.ts', '02-validate-artifacts.spec.ts'],
      use: { browserName: 'chromium', viewport: { width: 1440, height: 900 }, acceptDownloads: true },
    },
    // Full BRD v4 suite. Execution uploads 68 feed files and must be preceded by
    //   python scripts/reissue_e2e.py <generation>
    {
      name: 'e2e-execute',
      testMatch: ['e2e-01-execute.spec.ts'],
      use: { browserName: 'chromium', viewport: { width: 1440, height: 900 }, acceptDownloads: true },
    },
    // Judges the downloaded artifacts. Touches nothing; safe to re-run.
    {
      name: 'e2e-validate',
      testMatch: ['e2e-02-validate.spec.ts'],
      use: { browserName: 'chromium' },
    },
  ],
});
