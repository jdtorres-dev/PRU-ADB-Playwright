import * as fs from 'fs';
import * as path from 'path';

/**
 * The test-case registry.
 *
 * Generated from PRU_ADB_E2E_Test_Scenarios_v4.xlsx by scripts/build_registry.py.
 * The workbook is the definition of record — nothing in this project carries its
 * own copy of an expected error code or description.
 */

export interface FeedTarget {
  /** Feed file this rule's records live in. */
  feed: string;
  /** 1-based bundle number within the file. */
  bundleIndex: number;
  /** Record positions the bundle occupies, counting the submitting header as 1. */
  recordStart: number;
  recordEnd: number;
  recordCount: number;
  /**
   * How the record is driven:
   *   fault injected  the condition is forced by a field value in the file
   *   structural      the condition is forced by the shape of the bundle
   *   positive        the expected outcome is success
   *   precondition    depends on what is already committed in ADB
   *   header-level    sits on the submitting header, needs a file of its own
   *   carrier ...     the rule's fields have no position in the feed layout
   */
  cls: string;
  note: string;
  bd: string;
}

export interface TestCase {
  id: string;
  rule: string;
  topic: string;
  type: string;
  priority: string;
  route: string;
  /** Confidence C in BRD v4 — observe and record, never Pass or Fail. */
  bcr: boolean;
  expectedCode: string;
  expectedDescription: string;
  expectedDestination: string;
  validationSource: string;
  program: string;
  feeds: FeedTarget[];
  classes?: string[];
  /** LNAERROR | ADBSKIP | CNTLRPT | LOADFILE | ERRFILE | '' — where the BRD says the output goes. */
  destinationArtifact: string;
  /** True when the feed file actually forces the rule's condition. */
  conditionForced: boolean;
  /** True only when the condition is actually forced by the file. */
  executable: boolean;
  blockedReason: string;
}

export interface Feed {
  file: string;
  path: string;
  /** error-code | destination | positive | java-recovered | state | setup */
  family: string;
  code: string;
  destination: string;
  /** 0 = a setup file that commits state, uploaded first. 1 = everything else. */
  phase: number;
  records: number;
  bundles: number;
  cases: string[];
}

const DATA = path.join(__dirname, '..', 'data');

function read<T>(name: string): T {
  const p = path.join(DATA, name);
  if (!fs.existsSync(p)) {
    throw new Error(
      `${name} is missing. Run:  python scripts/build_registry.py\n` +
        `(or scripts/reissue_e2e.py <generation> to rebuild the feeds as well)`,
    );
  }
  return JSON.parse(fs.readFileSync(p, 'utf8')) as T;
}

export const loadTestCases = (): TestCase[] => read<TestCase[]>('test-cases.json');
export const loadFeeds = (): Feed[] => read<Feed[]>('feeds.json');

export interface Generation {
  generation: number;
  issuedAt: string;
  feedDir: string;
}

/**
 * The generation the feed files currently carry. Absent means the feeds were
 * built without a reissue, which is fine for a first run on a clean environment
 * and a problem on any run after that.
 */
export function loadGeneration(): Generation | null {
  const p = path.join(DATA, 'generation.json');
  return fs.existsSync(p) ? (JSON.parse(fs.readFileSync(p, 'utf8')) as Generation) : null;
}

/** Cases whose condition the feed file actually forces. Only these can return Pass or Fail. */
export const executableCases = (all: TestCase[]): TestCase[] => all.filter((c) => c.executable);

/** Cases that cannot return a verdict, with the reason. Recorded BLOCKED, never FAIL. */
export const blockedCases = (all: TestCase[]): TestCase[] => all.filter((c) => !c.executable);

/** Test cases whose records live in a given feed file. */
export function casesForFeed(all: TestCase[], feed: string): TestCase[] {
  return all.filter((c) => c.feeds.some((f) => f.feed === feed));
}
