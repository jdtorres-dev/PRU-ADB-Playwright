# PRU ADB - E2E test suite

Everything needed to run the BRD v4 suite against the HR Master Console, and the
evidence from the last execution.

Last run: **16 September 2026, generation 13** - 85 feed files, 284 test cases,
220 passed, 5 failed, 58 blocked, 1 observed.

---

## What is here

| Folder | What it holds |
|---|---|
| `automation/` | The Playwright suite: page object, validator, specs, registry, build scripts |
| `Test Cases/` | The test case workbook (the definition of record), the blocked-rule analysis, the QA test plan |
| `Test Data/` | 90 LNA feed files plus their manifests - the data uploaded during the run |
| `Reference/` | BRD v4, the error-code reference, the input file layout |
| `Evidence/` | What the last run produced: per-case verdicts, per-feed run records, captured console output |

`node_modules` is not included - install it. The downloaded artifact ZIPs are not
included either; they are produced by the run and come to about 80 MB.

---

## First run

```bash
cd automation
npm install
npx playwright install chromium
```

Two paths in the scripts point at this machine. Change them if the package moves:

- `ROOT` at the top of each file in `automation/scripts/`
- `DATA_ROOT` / feed paths in `automation/data/feeds.json` (rebuilt by `build_registry.py`)

---

## Running it

```bash
# 1. Issue a fresh generation. MANDATORY - see "No data reset" below.
python scripts/reissue_e2e.py 14

# 2. Upload every feed file and download its artifacts.   (~10 min)
npm run e2e:execute

# 3. Judge all 284 test cases. Touches nothing; re-runnable. (~30 sec)
npm run e2e:validate

# 4. Write the verdicts into the workbook.
python scripts/write_results.py
```

`npm run e2e:plan` lists what step 2 would upload, without uploading anything.
To run one feed file: `npx playwright test --project=e2e-execute --grep "B0607"`.

---

## No data reset

The environment never resets. A bundle whose firm record passes validation
commits its organisation, and presenting the same identifiers again raises
**B0700** instead of the condition under test.

`reissue_e2e.py <n>` rebuilds every feed file with generation-`n` identifiers, so
no bundle anywhere shares an identifier with any previous run. Run it immediately
before an execution, never during one. The execution phase refuses to start
without `data/generation.json`.

**Generations 1-13 are spent.** Start at 14.

---

## How a verdict is decided

The test is whether output landed at the destination the BRD assigns - not
whether a particular error code fired.

- **The feed forces the rule's condition** -> the output must reach that rule's
  destination. A pass here proves the rule. 101 of the last run's passes.
- **The record is valid** -> the right destination is the successful output. A
  valid record cannot appear on an error report, so being applied is correct.
  A pass here proves routing, not the rule. 119 of the last run's passes.

The expected error code is evidence, not the gate. Output reaching its
destination under a different code is recorded as a discrepancy, not a failure.

Three rules override everything above:

1. A Confidence C rule is **OBSERVED** - recorded, never passed or failed
   (QA Test Plan v1.00 section 6.3).
2. A case with no readable destination is **BLOCKED**, never FAIL.
3. An automation or environment failure is **BLOCKED**, never FAIL.

---

## The 284 test cases in TypeScript

The suite is data-driven: `tests/e2e-02-validate.spec.ts` reads
`data/test-cases.json` and generates one Playwright test per case, so the
workbook stays the single definition of record.

`tests/test-cases.generated.ts` mirrors all 284 as typed constants, for reading
and searching in an editor. Rebuild it with `python scripts/gen_ts_cases.py`.
It is generated - do not hand-edit.

---

## Known state at handover

| | |
|---|---|
| **5 failures** | BR-047, BR-172, BR-230, BR-233, BR-309. Each landed at a destination other than the assigned one. BR-230 and BR-309 were committed to the load output when the rules say to reject them. |
| **58 blocked** | 24 write to `errfile-<CCYYMMDD>.csv`, which has never appeared in any download. 31 to a Java exception, 1 to the log, 2 to nothing. No test data changes this. |
| **88 parked** | Need direct database access, tagged `SQL VERIFICATION` in the workbook. |
| **`SQL dump failed`** | Logged on 79 of 85 runs, in the console only. Raised with development. |

---

## The live console

The console at `/api/v1/ingestion/runs/{runId}/logs` is the only place that says
what became of an uploaded file:

```
INFO  HR1 feed ingestion complete: 0 bundle(s) committed, 1 rolled back, 3 record(s) skipped
```

**It is only available while the run is live** - a completed run returns 404. The
execution phase polls it during the run and saves the output to
`artifacts/e2e/console/`. Every verdict quotes the summary line.
